﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class AdminViewPayments : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        try
        {
            double total = 0;
            con.Open();
            string str = "select * from Customers where DateOforder='" + Calendar1.SelectedDate.ToShortDateString() + "' and Status='Delivered' ";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                total = total + Convert.ToDouble(reader.GetString(5).Trim());
            }
            reader.Close();
            SqlDataAdapter dap = new SqlDataAdapter(str, con);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                GridView1.DataSource = dt;
                lblpayment.Text = total.ToString();
            }
            else
            {
                GridView1.DataSource = null;
                lblpayment.Text = "0";
            }
            DataBind();
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
}