﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class CustomerPayment : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            lbldoo.Text = DateTime.Now.ToShortDateString();
            if (Session["payment"] == null)
            {

                txtorderid.Focus();
            }
            else
            {
                txtorderid.Text = Session["payment"].ToString();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnproceed_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (txtorderid.Text == "")
            {
                Response.Write("<script>alert('Please Enter Your OrderID  ! ! !');</script>");
            }
            else
            {
                con.Open();
                string str = "select sum(Quantity),sum(Total_Price) from Orders where OrderID=" + txtorderid.Text;
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    lbltotalbooks.Text = reader.GetValue(0).ToString();
                    lbltotalbill.Text = reader.GetValue(1).ToString();
                }
                else
                {
                    Response.Write("<script>alert('Incorrect OrderID  ! ! !');</script>");

                }
                con.Close();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnorder_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            bool exist = false;
            con.Open();
            string str = "select * from Customers where OrderID='" + txtorderid.Text.Trim() + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            if (reader.HasRows)
            {
                exist = true;
            }
            con.Close();
            if (exist == true)
            {
                Response.Write("<script>alert('Already Have Ordered / Delivered / Cancelled  ! ! !');</script>");

            }
            else
            {
                string status = "Ordered";
                con.Open();
                string str1 = "insert into Customers values(@id,@name,@address,@mno,@totalbooks,@bill,@doo,@status)";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                cmd1.Parameters.Add("@id", txtorderid.Text.Trim());
                cmd1.Parameters.Add("@name", txtname.Text.Trim());
                cmd1.Parameters.Add("@address", txtaddress.Text.Trim());
                cmd1.Parameters.Add("@mno", txtmno.Text.Trim());
                cmd1.Parameters.Add("@totalbooks", lbltotalbooks.Text);
                cmd1.Parameters.Add("@bill", lbltotalbill.Text);
                cmd1.Parameters.Add("@doo", lbldoo.Text);
                cmd1.Parameters.Add("@status", status);
                cmd1.ExecuteNonQuery();
                con.Close();
                Response.Redirect("CustomerOrderConfirm.aspx");
            }
        }
        catch (Exception e1)
        {
        }
    }

    protected void ddlcardtype_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void txtcardno_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtname_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtaddress_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtmno_TextChanged(object sender, EventArgs e)
    {

    }
}