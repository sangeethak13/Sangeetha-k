﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;

public partial class StaffDeleteBook : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");
    public void loadid()
    {
        try
        {
            ddlisbnno.Items.Clear();
            ddlisbnno.Items.Add("--Select--");
            con.Open();
            string str = "select ISBN_NO from Books";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ddlisbnno.Items.Add(reader.GetValue(0).ToString());
            }
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                loadid();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void btndelete_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            con.Open();
            string str = "delete from Books where ISBN_NO=" + ddlisbnno.Text;
            SqlCommand cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            con.Close();
            File.Delete(Server.MapPath(Session["imagepath"].ToString()));
            Image3.ImageUrl = null;
            loadid();
            GridView1.DataSource = null;
            DataBind();
            Response.Write("<script>alert('Book Details Removed Successfully ! ! !');</script>");
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlisbnno_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            string str = "select * from Books where ISBN_NO=" + ddlisbnno.Text;
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter dap = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            GridView1.DataSource = dt;
            DataBind();
            Session["imagepath"] = dt.Rows[0][6].ToString();
            Image3.ImageUrl = dt.Rows[0][6].ToString();
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
}