﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class AdminSearchBooks : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ddltitle.Items.Clear();
                ddltitle.Items.Add("--Select--");
                ddlauthor.Items.Clear();
                ddlauthor.Items.Add("--Select--");
                ddlpublisher.Items.Clear();
                ddlpublisher.Items.Add("--Select--");
                con.Open();
                string str = "select distinct(Title) from Books";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ddltitle.Items.Add(reader.GetString(0).Trim());

                }
                con.Close();
                con.Open();
                string str1 = "select distinct(Author) from Books";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataReader reader1 = cmd1.ExecuteReader();
                while (reader1.Read())
                {
                    ddlauthor.Items.Add(reader1.GetString(0).Trim());

                }
                con.Close();
                con.Open();
                string str2 = "select distinct(Publication) from Books";
                SqlCommand cmd2 = new SqlCommand(str2, con);
                SqlDataReader reader2 = cmd2.ExecuteReader();
                while (reader2.Read())
                {

                    ddlpublisher.Items.Add(reader2.GetString(0).Trim());

                }
                con.Close();
                con.Open();
                string str3 = "select * from Books ";
                SqlCommand cmd3 = new SqlCommand(str3, con);
                SqlDataAdapter dap = new SqlDataAdapter(cmd3);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                GridView1.DataSource = dt;
                DataBind();
                con.Close();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddltitle_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            string str = "select * from Books where Title='" + ddltitle.Text + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter dap = new SqlDataAdapter(str, con);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            GridView1.DataSource = dt;
            DataBind();
            con.Close();
            //ddlauthor.Text = "--Select--";
            //ddlpublisher.Text = "--Select--";
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlauthor_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            string str = "select * from Books where Author='" + ddlauthor.Text + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter dap = new SqlDataAdapter(str, con);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            GridView1.DataSource = dt;
            DataBind();
            con.Close();
            //ddltitle.Text = "--Select--";
            //ddlpublisher.Text = "--Select--";
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlpublisher_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            string str = "select * from Books where Publication='" + ddlpublisher.Text + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter dap = new SqlDataAdapter(str, con);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            GridView1.DataSource = dt;
            DataBind();
            con.Close();
            //ddlauthor.Text = "--Select--";
            //ddltitle.Text = "--Select--";
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnfilter_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddltitle.Text == "--Select--" || ddlauthor.Text == "--Select--" || ddlpublisher.Text == "--Select--")
            {
                Response.Write("<script>alert('Please Select All The Search Filters ! ! !');</script>");

            }
            else
            {
                con.Open();
                string str = "select * from Books where Publication='" + ddlpublisher.Text + "' and Author='" + ddlauthor.Text + "' and Title='" + ddltitle.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataAdapter dap = new SqlDataAdapter(str, con);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                }
                else
                {
                    Response.Write("<script>alert('Sorry No Books Found In This Category ! ! !');</script>");
                    GridView1.DataSource = null;

                }
                DataBind();
                con.Close();
            }
        }
        catch (Exception e1)
        {
        }
    }
}