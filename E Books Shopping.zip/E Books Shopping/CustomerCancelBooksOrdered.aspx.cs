﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class CustomerCancelBooksOrdered : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnproceed_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            bool exist = false;
            string status = "";
            con.Open();
            string str = "select Status from Customers where OrderID=" + txtorderid.Text;
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            if (reader.HasRows)
            {
                exist = true;
                status = reader.GetString(0).Trim();
            }
            con.Close();
            if (exist == true)
            {
                if (status == "Ordered")
                {
                    con.Open();
                    string str2 = "select * from Orders where OrderID=" + txtorderid.Text;
                    SqlCommand cmd2 = new SqlCommand(str2, con);
                    SqlDataAdapter dap2 = new SqlDataAdapter(cmd2);
                    DataTable dt2 = new DataTable();
                    dap2.Fill(dt2);
                    GridView2.DataSource = dt2;
                    DataBind();
                    con.Close();
                    con.Open();
                    string str3 = "select * from Customers where OrderID=" + txtorderid.Text;
                    SqlCommand cmd3 = new SqlCommand(str3, con);
                    SqlDataAdapter dap3 = new SqlDataAdapter(cmd3);
                    DataTable dt3 = new DataTable();
                    dap3.Fill(dt3);
                    GridView1.DataSource = dt3;
                    DataBind();
                    con.Close();
                    btncancel.Visible = true;
                }
                else
                {
                    Response.Write("<script>alert('Sorry This Order Is Already Have Dispatched Or Delivered Or Cancelled ! ! !');</script>");
                    GridView2.DataSource = null;
                    GridView1.DataSource = null;
                    DataBind();
                    btncancel.Visible = false;
                }
            }
            else
            {
                Response.Write("<script>alert('Invalid Order ID ! ! !');</script>");
                GridView2.DataSource = null;
                GridView1.DataSource = null;
                DataBind();
                btncancel.Visible = false;
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void btncancel_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            con.Open();
            string str = "update Customers set Status='Cancelled' where OrderID='" + txtorderid.Text.Trim() + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('Your Order Cancelled Succesfully ! ! !');</script>");
        }
        catch (Exception e1)
        {
        }
    }
}