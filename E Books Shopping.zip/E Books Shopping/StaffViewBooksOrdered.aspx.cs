﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class BooksOrdered : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ddlorderid.Items.Clear();
                ddlorderid.Items.Add("--Select--");
                con.Open();
                string str1 = "select * from Customers where Status='Ordered' ";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataReader reader1 = cmd1.ExecuteReader();
                while (reader1.Read())
                {
                    ddlorderid.Items.Add(reader1.GetString(0).Trim());
                }
                con.Close();
            }
            con.Open();
            string str = "select * from Customers where Status='Ordered' ";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter dap = new SqlDataAdapter(str, con);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            GridView1.DataSource = dt;
            DataBind();
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlorderid_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlorderid.Text != "--Select--")
            {
                con.Open();
                string str1 = "select * from Orders where OrderID='" + ddlorderid.Text + "'";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataAdapter dap = new SqlDataAdapter(str1, con);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                GridView2.DataSource = dt;
                DataBind();
                con.Close();
            }
            else
            {
                Response.Write("<script>alert('Please Select The Order ID ! ! !');</script>");

            }
        }
        catch (Exception e1)
        {
        }
    }
}