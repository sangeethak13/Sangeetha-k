﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;


public partial class CustomerBooksOrder : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");

    public void loadtogrid()
    {
        try
        {
            ddlisbnno.Items.Clear();
            ddlisbnno.Items.Add("--Select--");
            con.Open();
            string str3 = "select * from Orders where OrderID=" + lblorderid.Text;
            SqlCommand cmd3 = new SqlCommand(str3, con);
            SqlDataReader reader3 = cmd3.ExecuteReader();
            while (reader3.Read())
            {
                ddlisbnno.Items.Add(reader3.GetValue(1).ToString());
            }
            reader3.Close();
            SqlDataAdapter dap = new SqlDataAdapter(str3, con);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            GridView1.DataSource = dt;
            DataBind();
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
    public void totalbill()
    {
        try
        {
            con.Open();
            string str4 = "select sum(Total_Price) from Orders where OrderID=" + lblorderid.Text;
            SqlCommand cmd4 = new SqlCommand(str4, con);
            SqlDataReader reader4 = cmd4.ExecuteReader();
            reader4.Read();
            if (!reader4.IsDBNull(0))
            {
                lbltotalbill.Text = reader4.GetValue(0).ToString();
            }
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
    int orderid;
    public void GenerateOrderID()
    {
        try
        {
            con.Open();
            string str = "select max(OrderID) from Orders";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            if (reader.IsDBNull(0))
            {
                orderid = 11001;
            }
            else
            {


                orderid = Convert.ToInt32(reader.GetValue(0));
                orderid++;
            }
            con.Close();
            lblorderid.Text = orderid.ToString();
        }
        catch (Exception e1)
        {
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                con.Open();
                ddlbooktitle.Items.Clear();
                ddlbooktitle.Items.Add("--Select--");
                string str = "select distinct(Title) from Books";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ddlbooktitle.Items.Add(reader.GetString(0).Trim());
                }
                con.Close();
                GenerateOrderID();
                ddlqty.Items.Add("--Select--");
                for (int i = 1; i <= 50; i++)
                {
                    ddlqty.Items.Add(i.ToString());
                }
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlbooktitle_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ddlauthor.Items.Clear();
            ddlauthor.Items.Add("--Select--");
            con.Open();
            string str = "select Author,Picture from Books where Title='" + ddlbooktitle.Text + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ddlauthor.Items.Add(reader.GetString(0).Trim());
            }
            reader.Close();
            SqlDataAdapter dap = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            DataList1.DataSource = dt;
            DataBind();
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlauthor_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            string str = "select * from Books where Title='" + ddlbooktitle.Text + "' and Author='" + ddlauthor.Text + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            lblisbnno.Text = reader.GetValue(0).ToString();
            lblpublication.Text = reader.GetString(3).Trim();
            lblprice.Text = reader.GetString(4).Trim();
            Session["picture"] = reader.GetString(6).Trim();
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlqty_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlqty.Text != "--Select--")
            {
                double price, total;
                int qty;
                qty = Convert.ToInt32(ddlqty.Text);
                price = Convert.ToDouble(lblprice.Text);
                total = price * qty;
                lbltotalprice.Text = total.ToString();
            }
            else
            {

                lbltotalprice.Text = "";
                Response.Write("<script>alert('Please Select The Quantity ! ! !');</script>");

            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnadd_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            ddlisbnno.Items.Clear();
            ddlisbnno.Items.Add("--Select--");
            if (ddlqty.Text != "--Select--")
            {
                bool exist = false;
                con.Open();
                string str1 = "select * from Orders where ISBN_NO=@isbn and OrderID=@id";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                cmd1.Parameters.Add("@isbn", lblisbnno.Text);
                cmd1.Parameters.Add("@id", lblorderid.Text);
                SqlDataReader reader1 = cmd1.ExecuteReader();
                reader1.Read();
                if (reader1.HasRows)
                {
                    exist = true;
                }
                con.Close();
                if (exist == false)
                {
                    con.Open();
                    string str = "insert into Orders values(@id,@isbn,@title,@author,@publication,@price,@qty,@totalprice,@picture)";
                    SqlCommand cmd = new SqlCommand(str, con);
                    cmd.Parameters.Add("@id", Convert.ToInt32(lblorderid.Text));
                    cmd.Parameters.Add("@isbn", Convert.ToInt32(lblisbnno.Text));
                    cmd.Parameters.Add("@title", ddlbooktitle.Text);
                    cmd.Parameters.Add("@author", ddlauthor.Text);
                    cmd.Parameters.Add("@publication", lblpublication.Text);
                    cmd.Parameters.Add("@price", lblprice.Text);
                    cmd.Parameters.Add("@qty", Convert.ToInt32(ddlqty.Text));
                    cmd.Parameters.Add("@totalprice", Convert.ToDouble(lbltotalprice.Text));
                    cmd.Parameters.Add("@picture", Session["picture"].ToString());
                    cmd.ExecuteNonQuery();
                    con.Close();
                    Response.Write("<script>alert('Book Added To Your Cart ! ! !');</script>");
                }
                else
                {
                    con.Open();
                    string str2 = "update Orders set Quantity=@qty,Total_Price=@total where ISBN_NO=@isbn and OrderID=@id";
                    SqlCommand cmd2 = new SqlCommand(str2, con);
                    cmd2.Parameters.Add("@qty", Convert.ToInt32(ddlqty.Text));
                    cmd2.Parameters.Add("@total", lbltotalprice.Text);
                    cmd2.Parameters.Add("@id", Convert.ToInt32(lblorderid.Text));
                    cmd2.Parameters.Add("@isbn", Convert.ToInt32(lblisbnno.Text));
                    cmd2.ExecuteNonQuery();
                    con.Close();
                    Response.Write("<script>alert('Book Quantity Updated ! ! !');</script>");

                }
                ddlqty.Text = "--Select--";
            }
            else
            {
                Response.Write("<script>alert('Please Select The Quantity ! ! !');</script>");
            }
            loadtogrid();
            totalbill();
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnremove_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (ddlisbnno.Text == "--Select--")
            {
                Response.Write("<script>alert('Please Select The ISBN_NO To Remove From Cart ! ! !');</script>");

            }
            else
            {
                con.Open();
                string str = "delete from Orders where ISBN_NO=" + ddlisbnno.Text + " and OrderID='" + lblorderid.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert('Book Removed From Cart ! ! !');</script>");
                loadtogrid();
                totalbill();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnpayment_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            Session["payment"] = lblorderid.Text;
            Response.Redirect("CustomerPayment.aspx");
        }
        catch (Exception e1)
        {
        }
    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}