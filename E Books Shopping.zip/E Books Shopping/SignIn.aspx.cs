﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class SignIn : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsignin_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            con.Open();
            bool exist = false;
            string str = "select * from Login where Username='" + txtuname.Text.Trim() + "' and Password='" + txtpwd.Text.Trim() + "' and Type='" + ddlusertype.Text + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter dap = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                exist = true;
            }
            con.Close();

            if (exist == true)
            {
                Session["username"] = txtuname.Text.Trim();
                if (ddlusertype.Text == "Admin")
                {
                    Response.Redirect("AdminHome.aspx");
                }
                else
                {
                    Response.Redirect("StaffHome.aspx");
                }

            }
            else
            {
                Response.Write("<script>alert('Invalid User');</script>");

            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlusertype_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void txtuname_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtpwd_TextChanged(object sender, EventArgs e)
    {

    }
}