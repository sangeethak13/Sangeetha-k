﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class CustomerTrackBooksOrdered : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnproceed_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            bool exist = false;
            string status = "";
            con.Open();
            string str = "select Status from Customers where OrderID=" + txtorderid.Text;
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            if (reader.HasRows)
            {
                exist = true;
                status = reader.GetString(0).Trim();
            }
            con.Close();
            if (exist == true)
            {
                lblstatus.Text = status.ToString();
            }
            else
            {
                lblstatus.Text = "";
                Response.Write("<script>alert('Invalid Order ID ! ! !');</script>");

            }
        }
        catch (Exception e1)
        {
        }
    }
}