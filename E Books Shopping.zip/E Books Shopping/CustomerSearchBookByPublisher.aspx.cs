﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class CustomerSearchBookByCourse : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ddlpublisher.Items.Clear();
                ddlpublisher.Items.Add("--Select--");
                con.Open();
                string str = "select distinct(Publication) from Books";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ddlpublisher.Items.Add(reader.GetString(0).Trim());
                }
                con.Close();
                con.Open();
                string str1 = "select * from Books ";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataAdapter dap = new SqlDataAdapter(str1, con);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                GridView1.DataSource = dt;
                DataBind();
                con.Close();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlbooktitle_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            string str = "select * from Books where Publication='" + ddlpublisher.Text + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter dap = new SqlDataAdapter(str, con);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            GridView1.DataSource = dt;
            DataBind();
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
}