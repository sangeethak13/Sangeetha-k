﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Response.Redirect("SignOut.aspx");
        }
    }
    protected void btnsignout_Click(object sender, ImageClickEventArgs e)
    {
        Session["username"] = null;
        Response.Redirect("SignOut.aspx");
    }
}
