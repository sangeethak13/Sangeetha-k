﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class StaffAddBook : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");

    int isbnno;
    public void GenerateISBNNo()
    {
        try
        {
            con.Open();
            string str = "select max(ISBN_NO) from Books";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            if (reader.IsDBNull(0))
            {
                isbnno = 12001;
            }
            else
            {


                isbnno = Convert.ToInt32(reader.GetValue(0));
                isbnno++;
            }
            con.Close();
            lblisbnno.Text = isbnno.ToString();
        }
        catch (Exception e1)
        {
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            GenerateISBNNo();
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnadd_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string ext = System.IO.Path.GetExtension(FileUpload1.FileName);
            string imagepath;
            if (!FileUpload1.HasFile)
            {
                lblimage.Text = "Please Select Your Photo in JPG Format";
            }
            else
            {
                bool exist = false;
                con.Open();
                string str1 = "select * from Books where Title=@title and Author=@author and Publication=@publication";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                cmd1.Parameters.Add("@title", txttitle.Text.Trim());
                cmd1.Parameters.Add("@author", txtauthor.Text.Trim());
                cmd1.Parameters.Add("@publication", txtpublication.Text.Trim());
                SqlDataReader reader1 = cmd1.ExecuteReader();
                reader1.Read();
                if (reader1.HasRows)
                {
                    exist = true;
                }
                con.Close();
                if (exist == false)
                {
                    con.Open();
                    string str = "insert into Books values(@isbn,@title,@author,@publication,@price,@stock,@picture)";
                    SqlCommand cmd = new SqlCommand(str, con);
                    cmd.Parameters.Add("@isbn", Convert.ToInt32(lblisbnno.Text));
                    cmd.Parameters.Add("@title", txttitle.Text.Trim());
                    cmd.Parameters.Add("@author", txtauthor.Text.Trim());
                    cmd.Parameters.Add("@publication", txtpublication.Text.Trim());
                    FileUpload1.SaveAs(Server.MapPath("~/booksimages/" + lblisbnno.Text + ext));
                    imagepath = "~/booksimages/" + lblisbnno.Text + ext;
                    cmd.Parameters.Add("@picture", imagepath);
                    cmd.Parameters.Add("@price", txtprice.Text.Trim());
                    cmd.Parameters.Add("@stock", Convert.ToInt32(txtstock.Text.Trim()));
                    cmd.ExecuteNonQuery();
                    con.Close();
                    Response.Write("<script>alert('Books Details Saved Successfully ! ! !');</script>");
                    txttitle.Text = "";
                    txtauthor.Text = "";
                    txtprice.Text = "";
                    txtpublication.Text = "";
                    txtstock.Text = "";
                    GenerateISBNNo();
                }
                else
                {
                    Response.Write("<script>alert('This Book Details Are Already Exist ! ! !');</script>");

                }

            }
        }
        catch (Exception e1)
        {
        }
    }
}