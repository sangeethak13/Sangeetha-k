﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class StaffUpdateBook : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBooks;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ddlisbnno.Items.Clear();
                ddlisbnno.Items.Add("--Select--");
                con.Open();
                string str = "select ISBN_NO from Books";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ddlisbnno.Items.Add(reader.GetValue(0).ToString());
                }
                con.Close();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlisbnno_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            string str = "select * from Books where ISBN_NO=" + ddlisbnno.Text;
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            txttitle.Text = reader.GetString(1).Trim();
            txtauthor.Text = reader.GetString(2).Trim();
            txtpublication.Text = reader.GetString(3).Trim();
            Image3.ImageUrl = reader.GetString(6).Trim();
            txtprice.Text = reader.GetString(4).Trim();
            txtstock.Text = reader.GetValue(5).ToString();
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnupdate_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string ext = System.IO.Path.GetExtension(FileUpload1.FileName);
            con.Open();
            string str = "update Books set Title=@title,Author=@author,Publication=@publication,Price=@price,Stock=@stock where ISBN_NO=@isbnno";
            SqlCommand cmd = new SqlCommand(str, con);
            cmd.Parameters.Add("@isbnno", Convert.ToInt32(ddlisbnno.Text));
            cmd.Parameters.Add("@title", txttitle.Text.Trim());
            cmd.Parameters.Add("@author", txtauthor.Text.Trim());
            cmd.Parameters.Add("@publication", txtpublication.Text.Trim());
            cmd.Parameters.Add("@price", txtprice.Text.Trim());
            cmd.Parameters.Add("@stock", Convert.ToInt32(txtstock.Text.Trim()));
            cmd.ExecuteNonQuery();
            con.Close();
            if (FileUpload1.HasFile)
            {
                FileUpload1.SaveAs(Server.MapPath("~/booksimages/" + ddlisbnno.Text + ext));
            }
            Response.Write("<script>alert('Books Details Updated Successfully ! ! !');</script>");
        }
        catch (Exception e1)
        {
        }
    }
}